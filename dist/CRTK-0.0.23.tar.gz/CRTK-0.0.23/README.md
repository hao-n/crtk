# CRTK
Smart Contract Reverse Engineering Toolkits

See [crtk.readthedocs.io](https://crtk.readthedocs.io/en/latest/).